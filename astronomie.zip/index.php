<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'src/Exception.php';
require 'src/PHPMailer.php';
require 'src/SMTP.php';
$postData = $_POST;
if (isset($postData['email']) && $postData['email'] != '') {
    $mail = new PHPMailer();
    $mail->IsSMTP();
    $mail->Mailer = "smtp";

    $mail->SMTPDebug = 0;
    $mail->SMTPAuth = TRUE;
    $mail->SMTPSecure = "tls";
    $mail->Port = 587;
    $mail->Host = "smtp.gmail.com";
    $mail->Username = "hien.pham@bluecomgroup.com";
    $mail->Password = "hienHien291991";
    $mail->IsHTML(true);
    $mail->AddAddress("hien.pham@bluecomgroup.com", "recipient-name");
    $mail->SetFrom("hien.pham@bluecomgroup.com", "from-name");
    $mail->AddReplyTo("hien.pham@bluecomgroup.com", "reply-to-name");
    $mail->AddCC("cc-recipient-email@domain", "cc-recipient-name");
    $mail->Subject = "Test is Test Email sent via Gmail SMTP Server using PHP Mailer";
    $content = "<p><b>Email send from astronomie</b></p><p>email: " . $postData['email'] . "</p> <p>name: " . $postData['name'] . "</p><p>inquiry: " . $postData['inquiry'] . "</p>";
    $mail->MsgHTML($content);
    $mail->Send();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet/less" type="text/css" href="css/styles.less" />
    <title>Vietnam Weather</title>
</head>
<body>
<div class="cover-container d-flex h-100 p-3 mx-auto flex-column">
    <div class="mb-3">Notice: Vietnam Weather Page - Under Construction</div>
    <img alt="" src="./img/Geconverteerd1-4.png">
    <header class="masthead mb-5 mt-5">
        <div class="inner">
			<!--Đổi dòng tiêu đề to của page-->
            <h3 class="masthead-brand">Vietnam Weather for Amateur Astronomy Observatory</h3>
            <nav class="nav nav-masthead justify-content-center">
                <a class="nav-link active" href="#">Home</a>
                <a class="nav-link" href="#">Features</a>
                <a class="nav-link" href="#">Contact</a>
            </nav>
        </div>
    </header>
    <main role="main" class="text-center">
        <div class="cover-top">
            <div class="cover mb-4"></div>
			<!--Chỉnh sửa câu chú thích Page-->
            <p class="mt-2 mb-4">Trang web cung cấp thời tiết dành cho quan sát thiên văn tại Việt nam.</p>
            <div class="cover"></div>
        </div>

<!--Code chia 2 khối hình width=50
		<div class="d-flex flex-row mt-2 mb-2">
            <div class="p-4 w-50">
                <img class="w-100" src="http://www2.sat24.com/images.php?country=nl&sat=&rnd=" alt="">
            </div>
            <div class="p-4 w-50">
                <img class="w-100" src="http://www2.sat24.com/images.php?country=nl&sat=&rnd=" alt="">
            </div>
        </div>		
-->	
<!--Code chia thành 2 hình lớn width=100-->
        <div class="d-flex flex-row flex-wrap mt-2 mb-2">
            <div class="p-4 w-100">
                <img class="w-100" src="https://api.sat24.com/animated/TH/visual/3/SE%20Asia%20Standard%20Time/7560706" alt="">
            </div>
            <div class="p-4 w-100">
                <img class="w-100" src="https://api.sat24.com/animated/TH/infraPolair/3/SE%20Asia%20Standard%20Time/7417866" alt="">
            </div>
        </div>
<!--End of Code chia thành 2 hình lớn width=100-->

<!--Chỉnh sửa 2 hình RealTime BllomSky Camera-->
        <div class="cover"></div>
        <div class="d-flex flex-row mt-2 mb-5">
            <div class="p-5 w-50">
                <P>Real time BllomSky camera (Hanoi) (coming soon)</P>
                <img class="w-100 h-100" src="./img/l1.jpg" alt="">
                <div class="small">Update every 10 minutes</div>
            </div>
            <div class="p-5 w-50">
                <P>Real time BllomSky camera (Saigon) (coming soon)</P>
                <img class="w-100 h-100" src="./img/l2.jpg" alt="">
                <div class="small">Update every 10 minutes</div>
            </div>
        </div>
        <img alt="" src="./img/Geconverteerd1-4.png">
        <div class="">
            <p>AAG-Cloudwatcher</p>
            <iframe src="http://78.23.108.227:10800" width="800" height="1554" scrolling="NO" img="" border="0"> </iframe>
        </div>
        <div class="cover mt-3 mb-3"></div>
        <div class="mb-2">
            <p class="mt-2">Magnitude of the sky background in Magn./Arc.sec²</p>
            <div class="small">Update every 15 minutes</div>
        </div>
        <div class="cover mt-3 mb-3"></div>
        <div class="text-center mt-3 mb-3">
            <p>AAG-Cloudwatcher</p>
            <div class="d-flex flex-row justify-content-center mt-2 w-100">
                <div class="p-2 w-25">
                    <img class="w-100 h-100" src="./img/AAG_ImageCloudCondition.png" alt="">
                </div>
                <div class="p-2 w-25">
                    <img class="w-100 h-100" src="./img/AAG_ImageDayCondition.png" alt="">
                </div>
            </div>
            <div class="d-flex flex-row justify-content-center mt-2 w-100">
                <div class="p-2 w-25">
                    <img class="w-100 h-100" src="./img/AAG_ImageRainCondition.png" alt="">
                </div>
                <div class="p-2 w-25">
                    <img class="w-100 h-100" src="./img/AAG_ImageTemperature.png" alt="">
                </div>
                <div class="p-2 w-25">
                    <img class="w-100 h-100" src="./img/AAG_ImageWindCond.png" alt="">
                </div>
            </div>
        </div>
        <div class="cover mt-3 mb-3"></div>
        <div class="mb-5">
            <p class="mt-5 mb-5">Seeing conditions HoChiMinh City, Vietnam</p>
			
			<!--Link tọa độ cũ là https://clearoutside.com/forecast/51.17/4.31-->
			
            <a href="https://clearoutside.com/forecast/10.81/106.68"><img src="https://clearoutside.com/forecast_image_medium/10.81/106.68/forecast.png"></a>
        </div>
		<div class="fb-share-button" data-href="http://weathervn.com/" data-layout="button_count" data-size="large"><a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fweathervn.com%2F&amp;src=sdkpreparse" class="fb-xfbml-parse-ignore">Chia sẻ</a></div>
        <div class="mt-5 d-flex flex-row text-left contact p-2">
            <div class="w-50">
                <p>Active</p>
                <div class="cover"></div>
                <ul class="">
                    <li class="">Event</li>
                    <!--<li class="">Cras justo odio</li>
                    <li class="">Cras justo odio</li>
                    <li class="">Cras justo odio</li>-->
                </ul>
            </div>
            <div class="w-50">
                <h2>Contact form</h2>
                <form action="#" method="post">
                    <div class="form-group">
                        <label for="email">Your Email address</label>
                        <input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp" placeholder="Enter email">
                        <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                    </div>
                    <div class="form-group">
                        <label for="inquiry">Your Inquiry</label>
                        <input type="text" class="form-control" id="inquiry" name="inquiry" placeholder="Please type your inquiry here">
                    </div>
                    <div class="form-group">
                        <label for="name">Your Name</label>
                        <input type="text" class="form-control" id="name" name="name" placeholder="Please type your name here">
                    </div>
                    <div class="form-group form-check">
                        <input type="checkbox" class="form-check-input" id="exampleCheck1">
                        <label class="form-check-label" for="exampleCheck1">Check me out</label>
                    </div>
                    <button type="submit" class="btn dark">Submit</button>
                </form>
            </div>
        </div>
    </main>

    <footer class="mastfoot mt-auto">
        <div class="text-center">
            <p class="small">Copyright © All rights reserved. Made by VietCAD Co., Ltd - info@vietcad.com<a href="#">. Terms of use</a> | <a href="#">Privacy policy</a></p>
        </div>
    </footer>
</div>




<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<script src="//cdn.jsdelivr.net/npm/less" ></script>
<div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v7.0&appId=163517574259703&autoLogAppEvents=1" nonce="IJeVUNEQ"></script>
</body>
</html>
